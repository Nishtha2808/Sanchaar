/* ============================================================
   SANCHAAR — shared behavior
   ============================================================ */

/* Known stops on the Sanchaar network. In a real deployment this would
   come from a live stops/geocoding API instead of a static list. */
const SANCHAAR_STOPS = [
  { name: 'University Gate',    tag: 'Campus stop · high demand' },
  { name: 'Railway Station',    tag: 'Transit hub' },
  { name: 'Central Market',     tag: 'Market area · often crowded' },
  { name: 'City Hospital',      tag: 'Hospital' },
  { name: 'Old Square',         tag: 'Landmark' },
  { name: 'Tech Park',          tag: 'IT / office hub' },
  { name: 'Civil Lines',        tag: 'Residential' },
  { name: 'Bus Depot',          tag: 'Depot · route origin' },
  { name: 'Airport Road',       tag: 'Airport connector' },
  { name: 'Sanchaar Chowk',     tag: 'City centre' },
  { name: 'Lakeview Colony',    tag: 'Residential' },
  { name: 'Government College', tag: 'Campus stop' },
];

const STOP_ICON = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 22s7-4.4 7-11V5l-7-3-7 3v6c0 6.6 7 11 7 11Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';

function rankStops(query) {
  if (!query.trim()) {
    // No input yet: surface popular / high-demand stops as a smart default,
    // the way a generative recommendation would suggest likely picks.
    return { label: 'Suggested for you', items: SANCHAAR_STOPS.filter(s => /high demand|hub|centre/.test(s.tag)).slice(0, 4) };
  }
  const q = query.toLowerCase();
  const scored = SANCHAAR_STOPS
    .map(stop => {
      const idx = stop.name.toLowerCase().indexOf(q);
      if (idx === -1) return null;
      // earlier match position + shorter name = more relevant
      const score = idx * 10 + stop.name.length * 0.1;
      return { ...stop, idx, score };
    })
    .filter(Boolean)
    .sort((a, b) => a.score - b.score)
    .slice(0, 6);
  return { label: scored.length ? 'Matching stops' : null, items: scored };
}

function highlightMatch(name, query) {
  if (!query.trim()) return name;
  const idx = name.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return name;
  return name.slice(0, idx) + '<mark>' + name.slice(idx, idx + query.length) + '</mark>' + name.slice(idx + query.length);
}

function setupStopAutocomplete(inputId, listId) {
  const input = document.getElementById(inputId);
  const list = document.getElementById(listId);
  if (!input || !list) return;
  let activeIndex = -1;

  function renderList(query) {
    const { label, items } = rankStops(query);
    list.innerHTML = '';

    if (!items.length) {
      list.innerHTML = '<div class="suggest-empty">No stops found — try a different name</div>';
      list.classList.add('open');
      return;
    }

    if (label) {
      const lbl = document.createElement('div');
      lbl.className = 'suggest-section-label';
      lbl.textContent = label;
      list.appendChild(lbl);
    }

    items.forEach(stop => {
      const item = document.createElement('div');
      item.className = 'suggest-item';
      item.setAttribute('role', 'option');
      item.innerHTML =
        '<span class="ic">' + STOP_ICON + '</span>' +
        '<span class="meta"><span>' + highlightMatch(stop.name, query) + '</span><small>' + stop.tag + '</small></span>';
      item.addEventListener('mousedown', e => {
        e.preventDefault();
        input.value = stop.name;
        list.classList.remove('open');
      });
      list.appendChild(item);
    });

    list.classList.add('open');
    activeIndex = -1;
  }

  function setActive(items) {
    items.forEach(it => it.classList.remove('active'));
    if (items[activeIndex]) {
      items[activeIndex].classList.add('active');
      items[activeIndex].scrollIntoView({ block: 'nearest' });
    }
  }

  input.addEventListener('focus', () => renderList(input.value));
  input.addEventListener('input', () => renderList(input.value));
  input.addEventListener('blur', () => setTimeout(() => list.classList.remove('open'), 130));

  input.addEventListener('keydown', e => {
    const items = list.querySelectorAll('.suggest-item');
    if (!items.length) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      activeIndex = Math.min(activeIndex + 1, items.length - 1);
      setActive(items);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      activeIndex = Math.max(activeIndex - 1, 0);
      setActive(items);
    } else if (e.key === 'Enter') {
      if (activeIndex >= 0) {
        e.preventDefault();
        items[activeIndex].dispatchEvent(new Event('mousedown'));
      }
    } else if (e.key === 'Escape') {
      list.classList.remove('open');
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {

  /* ---- animate progress / meter bars in on load ---- */
  document.querySelectorAll('.progress > span[data-fill]').forEach(el => {
    const target = el.getAttribute('data-fill');
    el.style.width = '0%';
    requestAnimationFrame(() => {
      el.style.transition = 'width 900ms cubic-bezier(.2,.8,.2,1)';
      el.style.width = target + '%';
    });
  });

  /* ---- occupancy meter dots (segmented bars) ---- */
  document.querySelectorAll('.meter[data-occ]').forEach(meter => {
    const pct = parseInt(meter.getAttribute('data-occ'), 10);
    const level = meter.getAttribute('data-level') || 'low';
    const color = level === 'high' ? 'var(--red-500)' : level === 'mod' ? 'var(--amber-500)' : 'var(--green-500)';
    const total = 10;
    const on = Math.round((pct / 100) * total);
    meter.style.setProperty('--fill', color);
    meter.innerHTML = '';
    for (let i = 0; i < total; i++) {
      const seg = document.createElement('i');
      if (i < on) seg.classList.add('on');
      meter.appendChild(seg);
    }
  });

  /* ---- dashboard sidebar tab switching (single-page sections) ---- */
  const navLinks = document.querySelectorAll('.side-nav a[data-section]');
  const sections = document.querySelectorAll('[data-panel]');
  if (navLinks.length && sections.length) {
    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        navLinks.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        const target = link.getAttribute('data-section');
        sections.forEach(sec => {
          sec.style.display = sec.getAttribute('data-panel') === target ? '' : 'none';
        });
      });
    });
  }

  /* ---- mobile menu toggle on marketing/passenger pages ---- */
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinksBox = document.querySelector('.nav-links');
  if (menuToggle && navLinksBox) {
    menuToggle.addEventListener('click', () => {
      navLinksBox.classList.toggle('open');
    });
  }

  /* ---- simple "find buses" interaction on passenger page ---- */
  const findBtn = document.getElementById('findBusesBtn');
  if (findBtn) {
    findBtn.addEventListener('click', () => {
      document.getElementById('busResults')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  /* ---- swap From / To values ---- */
  const swapBtn = document.getElementById('swapBtn');
  const fromInput = document.getElementById('fromInput');
  const toInput = document.getElementById('toInput');
  if (swapBtn && fromInput && toInput) {
    swapBtn.addEventListener('click', () => {
      const tmp = fromInput.value;
      fromInput.value = toInput.value;
      toInput.value = tmp;
      swapBtn.style.transform = 'rotate(180deg)';
      setTimeout(() => { swapBtn.style.transform = ''; }, 200);
    });
  }

  /* ---- stop autocomplete with ranked / "AI-style" recommendations ---- */
  setupStopAutocomplete('fromInput', 'fromSuggest');
  setupStopAutocomplete('toInput', 'toSuggest');

  /* ---- live dot pulse position along route line (route.html) ---- */
  const liveDot = document.getElementById('liveBusDot');
  const routePath = document.getElementById('routeLinePath');
  if (liveDot && routePath && routePath.getTotalLength) {
    const len = routePath.getTotalLength();
    let progress = 0.28; // starting position along the route
    setInterval(() => {
      progress += 0.004;
      if (progress > 1) progress = 0;
      const pt = routePath.getPointAtLength(progress * len);
      liveDot.setAttribute('cx', pt.x);
      liveDot.setAttribute('cy', pt.y);
    }, 60);
  }

  /* ---- deploy bus button feedback (dashboard.html) ---- */
  const deployBtn = document.getElementById('deployBusBtn');
  if (deployBtn) {
    deployBtn.addEventListener('click', () => {
      deployBtn.textContent = '✓ Bus B12 deployed to Route RLY → UNI';
      deployBtn.disabled = true;
      deployBtn.style.opacity = '.7';
    });
  }

  /* ---- take alternate bus button (route.html alert card) ---- */
  const takeAltBtn = document.getElementById('takeAltBtn');
  if (takeAltBtn) {
    takeAltBtn.addEventListener('click', () => {
      takeAltBtn.textContent = '✓ Switched to Bus B12';
      takeAltBtn.disabled = true;
      takeAltBtn.style.opacity = '.7';
    });
  }
});
